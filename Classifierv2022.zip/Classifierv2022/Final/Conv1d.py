import pandas as pd
import numpy as np
import keras

import processTrainData
import processValiationData

processTrainData.getDataSet(r"E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir", "data.csv", "correctData.csv",
                            "oppositeData.csv")

processTrainData.mergeAccGyro(6, r"E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\datas\train\correct", 10,
                              r"E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir", "correctData.csv", 1)
processTrainData.mergeAccGyro(6, r"E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\datas\train\opposite", 10,
                              r"E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir", "oppositeData.csv", 0)

processValiationData.SplitAccGyroTestData(4, r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\datas\test\attack', 10,
                                          r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir\test',
                                          'TestData.csv', 0)
processValiationData.ContiuneSplitAccGyroData(5, 4,
                                              r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\datas\test\testTrain',
                                              10,
                                              r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir\test',
                                              'TestData.csv', 1)

path = r"E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir\data.csv"
df1 = pd.read_csv(path)
df1 = df1.drop(columns=['Unnamed: 0'])

trainY = np.array(df1['target'])
trainX = np.array(df1.drop(columns=['target']))
trainX = np.expand_dims(trainX, axis=2)


def build_model():
    # 构造一维卷积网络，适用于从一维时间序列中提取特征
    model = keras.models.Sequential([
        keras.layers.BatchNormalization(),
        keras.layers.Conv1D(100, 3, padding='valid', input_shape=(6, 1), activation='relu'),
        keras.layers.Conv1D(100, 3, activation='relu', padding='same'),
        keras.layers.MaxPooling1D(pool_size=4, padding='valid'),
        keras.layers.Conv1D(160, 3, activation='relu', padding='same'),
        keras.layers.Conv1D(160, 3, activation='relu', padding='same'),
        keras.layers.GlobalAveragePooling1D(),
        keras.layers.BatchNormalization(),
        keras.layers.Dropout(0.5),
        keras.layers.Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam',
                  loss='binary_crossentropy',
                  metrics=['accuracy', 'AUC'])
    return model


for Count in range(10):
    model = build_model()
    history1 = model.fit(trainX,
                         trainY,
                         epochs=50,  # 在全数据集上迭代120次
                         batch_size=256)
    # plt.figure(1)
    # # summarize history for accuracy
    # plt.subplot(211)
    # plt.plot(history1.history['accuracy'])
    # # plt.plot(history1.history['val_accuracy'])
    # plt.title('Model Accuracy')
    # plt.ylabel('Accuracy')
    # plt.xlabel('Epoch')
    # plt.legend(['Training'], loc='lower right')
    #
    # # summarize history for loss
    # plt.subplot(212)
    # plt.plot(history1.history['loss'])
    # # plt.plot(history1.history['val_loss'])
    # plt.title('Model Loss')
    # plt.ylabel('Loss')
    # plt.xlabel('Epoch')
    # plt.legend(['Training'], loc='upper right')
    # plt.tight_layout()

    # 使用test数据
    res = []
    tTP = tFN = tFP = tTN = 0
    for i in range(1, 8 + 1):
        for j in range(1, 10 + 1):
            filePath = r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir\test' + "\\" + str(i) + "-" + str(
                j) + "TestData.csv"
            TempDF = pd.read_csv(filePath)
            TempDF = TempDF.fillna(method='pad')
            TempDFy = np.array(TempDF['target'])
            TempDFx = np.array(TempDF.drop(columns=['target']))
            TempDFx = np.expand_dims(TempDFx, axis=2)
            # expectancy = list(df1.loc[:, 'target'].values)[0]
            if i >= 5:
                expectancy = 1
            else:
                expectancy = 0

            predictions = model.predict(TempDFx)
            suit = notSuit = 0
            for a in predictions:
                if a[0] > 0.80:
                    suit += 1
                else:
                    notSuit += 1
            percentage = suit / (suit + notSuit)
            res.append(percentage)
            if percentage > 0.625:  # 预测结果
                if expectancy is 1:  # 实际结果
                    tTP += 1
                else:
                    tFP += 1
            else:
                if expectancy is 0:
                    tTN += 1
                else:
                    tFN += 1
    outputFileName = (str(Count) + "eachPercentage.txt")
    with open(outputFileName, 'w') as f:
        for i in res:
            f.write(str(i) + '\n')

    print(str(Count) + "FAR:", tFP / (tFP + tTN))
    print(str(Count) + "FRR:", tFN / (tTP + tFN))

    # plt.show()
