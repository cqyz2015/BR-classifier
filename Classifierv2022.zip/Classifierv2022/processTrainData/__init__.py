import pandas as pd

def getDataSet(motherPath, outputName, fileName1, fileName2):
    """
    :param motherPath:上级路径
    :param outputName:输出文件名
    :param fileName1:文件名1
    :param fileName2:文件名2
    :return:void
    """
    f1 = pd.read_csv(motherPath + "\\" + fileName1)
    f2 = pd.read_csv(motherPath + "\\" + fileName2)  # 跳过第一列赘余索引
    files = [f1, f2]
    res = pd.concat(files)
    res = res.reset_index(drop=True)  # 重新设置行号
    res.to_csv(motherPath + "\\" + outputName)
    return None

def mergeAccGyro(depth, MotherPath, sampleCount, outputPath, outputName, flag):
    """
    :param depth: 总样本数量
    :param MotherPath: 源文件父路径
    :param sampleCount: 手势重复次数
    :param outputPath: 输出文件的父路径
    :param outputName: 输出文件的文件名,csv格式
    :param flag: 如果为正例则为1，否则为0
    :return: void
    """
    solveLst = ['acc', 'gyro']
    colName = ['ax', 'ay', 'az', 'gx', 'gy', 'gz', 'target']
    tempDf = \
        {colName[0]: [], colName[1]: [], colName[2]: [], colName[3]: [], colName[4]: [], colName[5]: [], colName[6]: []}
    for i in range(1, depth + 1):
        for j in range(1, sampleCount + 1):
            Rows = [0, 0]
            for k in range(0, 2):
                path = MotherPath + "\\" + str(i) + "\\" + str(j) + solveLst[k] + ".csv"
                df = pd.read_csv(path, skiprows=[-1], usecols=['x', 'y', 'z'], dtype='float64')
                df = df.fillna(method='pad')
                # df = df.diff()
                df.drop([0], inplace=True)
                for row in df.itertuples():
                    x = getattr(row, 'x')
                    y = getattr(row, 'y')
                    z = getattr(row, 'z')
                    if x == y == z == 0:
                        continue
                    tempDf[colName[0 + k * 3]].append(x)
                    tempDf[colName[1 + k * 3]].append(y)
                    tempDf[colName[2 + k * 3]].append(z)
                    Rows[k] += 1
                if k is 1:
                    if Rows[0] > Rows[1]:
                        tmp = Rows[0]
                        while tmp != Rows[1]:
                            del tempDf[colName[0]][tmp - 1]
                            del tempDf[colName[1]][tmp - 1]
                            del tempDf[colName[2]][tmp - 1]
                            tmp -= 1
                    else:
                        tmp = Rows[1]
                        while tmp != Rows[0]:
                            del tempDf[colName[3]][tmp - 1]
                            del tempDf[colName[4]][tmp - 1]
                            del tempDf[colName[5]][tmp - 1]
                            tmp -= 1
            for m in range(0, min(Rows)):
                tempDf['target'].append(flag)
    NewDf = pd.DataFrame(tempDf)
    NewDf.to_csv(outputPath + "\\" + outputName, index=False, columns=colName)