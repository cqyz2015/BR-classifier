import pandas as pd


def getDataSet(motherPath, outputName, fileName1, fileName2):
    """
    :param motherPath:上级路径
    :param outputName:输出文件名
    :param fileName1:文件名1
    :param fileName2:文件名2
    :return:void
    """
    f1 = pd.read_csv(motherPath + "\\" + fileName1)
    f2 = pd.read_csv(motherPath + "\\" + fileName2)  # 跳过第一列赘余索引
    files = [f1, f2]
    res = pd.concat(files)
    res = res.reset_index(drop=True)  # 重新设置行号
    res.to_csv(motherPath + "\\" + outputName)



