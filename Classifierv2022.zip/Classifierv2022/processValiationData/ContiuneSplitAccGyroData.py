import pandas as pd


def minElem(a, b, c):
    temp = min(a, b)
    temp = min(temp, c)
    return temp


# 处理逻辑：
# 将同一样本的acc，gyro数据处理后放在一个单独的csv文件里面
# 测试集中一份样本的一个属性就对应这样的一个csv文件。

def run(goon, depth, MotherPath, sampleCount, outputPath, outputName, flag):
    """
    :param goon: 断点标号
    :param depth: 剩余样本数目
    :param MotherPath: 父路径
    :param sampleCount: 手势数量
    :param outputPath: 输出路径
    :param outputName: 输出文件统一后缀名
    :param flag: 是否为正例
    :return: void
    """
    solveLst = ['acc', 'gyro']
    colName = ['ax', 'ay', 'az', 'gx', 'gy', 'gz', 'target']
    tempDf = \
        {colName[0]: [], colName[1]: [], colName[2]: [], colName[3]: [], colName[4]: [], colName[5]: [], colName[6]: []}
    for i in range(goon, depth + goon):
        for j in range(1, sampleCount + 1):
            Rows = [0, 0]
            for k in range(0, 2):
                path = MotherPath + "\\" + str(i) + "\\" + str(j) + solveLst[k] + ".csv"
                df = pd.read_csv(path, skiprows=[-1], usecols=['x', 'y', 'z'], dtype='float64')
                df = df.fillna(method='pad')
                # df = df.diff()
                df.drop([0], inplace=True)
                for row in df.itertuples(index=2):
                    x = getattr(row, 'x')
                    y = getattr(row, 'y')
                    z = getattr(row, 'z')
                    if x == y == z == 0:
                        continue
                    tempDf[colName[0 + k * 3]].append(x)
                    tempDf[colName[1 + k * 3]].append(y)
                    tempDf[colName[2 + k * 3]].append(z)
                    Rows[k] += 1
                if k is 1:
                    if Rows[0] > Rows[1]:
                        tmp = Rows[0]
                        while tmp != Rows[1]:
                            del tempDf[colName[0]][tmp - 1]
                            del tempDf[colName[1]][tmp - 1]
                            del tempDf[colName[2]][tmp - 1]
                            tmp -= 1
                    else:
                        tmp = Rows[1]
                        while tmp != Rows[0]:
                            del tempDf[colName[3]][tmp - 1]
                            del tempDf[colName[4]][tmp - 1]
                            del tempDf[colName[5]][tmp - 1]
                            tmp -= 1
            for m in range(0, min(Rows)):
                tempDf['target'].append(flag)
            dfA = pd.DataFrame(tempDf)
            dfA.to_csv(outputPath + "\\" + str(i) + "-" + str(j) + outputName, index=False, columns=colName)
            # 恢复
            for ls in tempDf.values():
                ls.clear()


run(5, 4, r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\datas\test\testTrain', 10,
    r'E:\PROGRAM DESIGNING\PycharmProjs\Classifierv2\testDir\test', 'TestData.csv', 1)
