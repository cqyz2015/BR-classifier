# 用于分割各个验证集的单样本预测值，便于统计

lst=[]

with open("ans.txt","a+") as file:
    for i in range(8):
        for j in range(10):
            tmp=input()
            lst.append((tmp))
        for e in lst:
            file.write(e+" ")
        file.write("\n")
        lst.clear()