folderSeq = [1, 10, 2, 3, 4, 5, 6, 7, 8, 9]


def func(count):
    tails = ['acc', 'gyro', 'point']
    for i in range(1, count + 1):
        for j in range(0, 3):
            print(str(i) + tails[j] + ".csv")


func(12)
